<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_1f989dd4ff359d0df913336e9fc24b736805d149fddbc9c11365f9c22fc98667 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Вход в админ панель \"Amnesia\"";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "<div class=\"container\">
    <div class=\"flex-fill d-flex flex-column justify-content-center py-4\">
      <div class=\"container-tight py-6\">
        <div class=\"text-center mb-4\">
            <a href=\".\">
              <img src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/assets/images/logo/amnesia-black.png"), "html", null, true);
        echo "\" class=\"amnesia-logo\" alt=\"логотип компании Амнезия\">
            </a>
        </div>
\t\t<form method=\"post\" class=\"my-login-validation card card-md\" novalidate=\"\">
\t\t\t";
        // line 14
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 14, $this->source); })())) {
            // line 15
            echo "            \t<div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 15, $this->source); })()), "messageKey", [], "any", false, false, false, 15), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 15, $this->source); })()), "messageData", [], "any", false, false, false, 15), "security"), "html", null, true);
            echo "</div>
        \t";
        }
        // line 17
        echo "\t\t    ";
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 17, $this->source); })()), "user", [], "any", false, false, false, 17)) {
            // line 18
            echo "            <div class=\"mb-3\">                                           
\t\t\t\tВы вошли как ";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 19, $this->source); })()), "user", [], "any", false, false, false, 19), "username", [], "any", false, false, false, 19), "html", null, true);
            echo ", <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Выйти</a>
            </div>
        \t";
        }
        // line 22
        echo "          <div class=\"card-body\">
            <h2 class=\"card-title text-center mb-4\">Вход в аккаунт</h2>
            <div class=\"mb-3\">
              <label class=\"form-label\">Email</label>
              <input type=\"email\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 26, $this->source); })()), "html", null, true);
        echo "\" name=\"email\" id=\"inputEmail\" class=\"form-control mb-3\" required autofocus>
            </div>
            <div class=\"mb-2\">
              <label class=\"form-label\">
                Пароль
                <span class=\"form-label-description\">
                    <a href=\"#\" class=\"float-right\">\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\tЗабыли пароль?
\t\t\t\t\t</a>
                </span>
              </label>
              <div class=\"input-group input-group-flat\">
                <input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" required data-eye>
                <span class=\"input-group-text pb-0\">
                  <a href=\"#\" class=\"link-secondary\" title=\"Show password\" data-bs-toggle=\"tooltip\"><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\"/><circle cx=\"12\" cy=\"12\" r=\"2\" /><path d=\"M22 12c-2.667 4.667 -6 7 -10 7s-7.333 -2.333 -10 -7c2.667 -4.667 6 -7 10 -7s7.333 2.333 10 7\" /></svg>
                  </a>
                </span>
              </div>
            </div>
            <div class=\"mb-2\">
              <label class=\"form-check\">
                <input type=\"checkbox\" name=\"_remember_me\" id=\"remember\" class=\"form-check-input\"/>
                <span class=\"form-check-label\">Запомнить меня</span>
              </label>
            </div>
\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\">
            <div class=\"form-footer\">
              <button type=\"submit\" class=\"btn btn-dark w-100\">Войти</button>
            </div>
          </div>
        </form>
       ";
        // line 60
        echo "      </div>
    </div>
        </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 60,  158 => 51,  130 => 26,  124 => 22,  116 => 19,  113 => 18,  110 => 17,  104 => 15,  102 => 14,  95 => 10,  88 => 5,  78 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Вход в админ панель \"Amnesia\"{% endblock %}
{% block body %}
<div class=\"container\">
    <div class=\"flex-fill d-flex flex-column justify-content-center py-4\">
      <div class=\"container-tight py-6\">
        <div class=\"text-center mb-4\">
            <a href=\".\">
              <img src=\"{{ asset('/assets/images/logo/amnesia-black.png') }}\" class=\"amnesia-logo\" alt=\"логотип компании Амнезия\">
            </a>
        </div>
\t\t<form method=\"post\" class=\"my-login-validation card card-md\" novalidate=\"\">
\t\t\t{% if error %}
            \t<div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
        \t{% endif %}
\t\t    {% if app.user %}
            <div class=\"mb-3\">                                           
\t\t\t\tВы вошли как {{ app.user.username }}, <a href=\"{{ path('app_logout') }}\">Выйти</a>
            </div>
        \t{% endif %}
          <div class=\"card-body\">
            <h2 class=\"card-title text-center mb-4\">Вход в аккаунт</h2>
            <div class=\"mb-3\">
              <label class=\"form-label\">Email</label>
              <input type=\"email\" value=\"{{ last_username }}\" name=\"email\" id=\"inputEmail\" class=\"form-control mb-3\" required autofocus>
            </div>
            <div class=\"mb-2\">
              <label class=\"form-label\">
                Пароль
                <span class=\"form-label-description\">
                    <a href=\"#\" class=\"float-right\">\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\tЗабыли пароль?
\t\t\t\t\t</a>
                </span>
              </label>
              <div class=\"input-group input-group-flat\">
                <input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" required data-eye>
                <span class=\"input-group-text pb-0\">
                  <a href=\"#\" class=\"link-secondary\" title=\"Show password\" data-bs-toggle=\"tooltip\"><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\"/><circle cx=\"12\" cy=\"12\" r=\"2\" /><path d=\"M22 12c-2.667 4.667 -6 7 -10 7s-7.333 -2.333 -10 -7c2.667 -4.667 6 -7 10 -7s7.333 2.333 10 7\" /></svg>
                  </a>
                </span>
              </div>
            </div>
            <div class=\"mb-2\">
              <label class=\"form-check\">
                <input type=\"checkbox\" name=\"_remember_me\" id=\"remember\" class=\"form-check-input\"/>
                <span class=\"form-check-label\">Запомнить меня</span>
              </label>
            </div>
\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\">
            <div class=\"form-footer\">
              <button type=\"submit\" class=\"btn btn-dark w-100\">Войти</button>
            </div>
          </div>
        </form>
       {# <div class=\"text-center text-muted mt\">
          Vous n'avez pas de compte? <a href=\"{{ url('company_workers_inscription') }}\" tabindex=\"-1\">Créer un compte</a>
        </div> #}
      </div>
    </div>
        </div>

{# block body %}
<body class=\"my-login-page\">
\t<section class=\"h-100\">
\t\t<div class=\"container h-100\">
\t\t\t<div class=\"row justify-content-md-center h-100\">
\t\t\t\t<div class=\"card-wrapper\">
\t\t\t\t\t<div>
\t\t\t\t\t\t<img src=\"{{ asset('assets/images/logo-sga.jpg') }}\" class=\"mt-2\" alt=\"logo\">
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"card fat\">
\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t<h4 class=\"card-title\">Login</h4>
                                <form method=\"post\" class=\"my-login-validation\" novalidate=\"\">
\t\t\t\t
                                    {% if error %}
                                        <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
                                    {% endif %}

                                    {% if app.user %}
                                        <div class=\"mb-3\">                                           
\t\t\t\t\t\t\t\t\t\t\tVous êtes connecté en tant que {{ app.user.username }}, <a href=\"{{ path('app_logout') }}\">Se déconnecter</a>
                                        </div>
                                    {% endif %}
                                        <div class=\"form-group\">
                                        <label for=\"inputEmail\">Email</label>
                                        <input type=\"email\" value=\"{{ last_username }}\" name=\"email\" id=\"inputEmail\" class=\"form-control mb-3\" required autofocus>
                                        
                                        <label for=\"inputPassword\">Mot de passe
                                        <a href=\"{{ path('reset_password') }}\" class=\"float-right\">\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\tMot de passe oublié?
\t\t\t\t\t\t\t\t\t\t</a>
                                        </label>
                                        <input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" required data-eye>
                                    </div>
                                    <div class=\"form-group\">
\t\t\t\t\t\t\t\t\t<div class=\"custom-checkbox custom-control\">
\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"_remember_me\" id=\"remember\" class=\"custom-control-input\">
\t\t\t\t\t\t\t\t\t\t<label for=\"remember\" class=\"custom-control-label\">Souviens-toi de moi</label>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
                             <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\">
                            <div class=\"form-group m-0\">
\t\t\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary btn-block custom-button\">\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\tS'identifier
\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"mt-4 text-center\">\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\tVous n'avez pas de compte? <a href=\"{{ url('inscription_admin') }}\" >Créer une</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"footer\">
\t\t\t\t\t\tCopyright &copy; 2017 &mdash; SGA 
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>#}
{% endblock %}
", "security/login.html.twig", "/Users/yulia/amnesia.moscow/amnesia.moscow/templates/security/login.html.twig");
    }
}
