/* MARQUEE (RUNNING BANDO)*/

$(function() {
    $('.marquee-moving-left').marquee({
      duration: 30000,
      startVisible: true,
      duplicated: true
    });
  });

  $(function() {
    $('.marquee-moving-right').marquee({
      duration: 30000,
      startVisible: true,
      duplicated: true
    });
  });


  